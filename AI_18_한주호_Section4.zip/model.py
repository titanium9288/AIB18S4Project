# 필요한 라이브러리 불러오기
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import VotingClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import RandomizedSearchCV


# 데이터 불러오기 (경로는 실제 데이터셋 경로로 수정해야 합니다)
data = pd.read_csv("cleared.csv")
# data = pd.read_csv("high_diamond_ranked_10min.csv")
# data = data.drop("gameId", axis=1)

# 특성과 레이블 분리
# X = data.drop("blueWins", axis=1)
X = data[["blueKillScoreDiff"]]
y = data["blueWins"]

# 특성 이름 가져오기
features = X.columns.tolist()

# 특성 전략 설정
strategies = {feature: "mean" for feature in features}
categorical_indicator = [
    "FirstBlood",
    "Dragons",
    "Heralds",
    "TowersDestroyed",
    "KillScoreDiff",
]
categorical_features = [
    feature
    for feature in features
    if any(indicator in feature for indicator in categorical_indicator)
]
for feature in categorical_features:
    strategies[feature] = "mode"

# 데이터셋 분할
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# 랜덤 포레스트 모델 생성
rf = RandomForestClassifier(
    random_state=42,
)


def predict_win_probability(model, features, strategies, **kwargs):
    # 모든 특성에 대한 기본값 설정 (평균값 혹은 최빈값)
    example = {}
    for feature in features:
        if strategies[feature] == "mean":
            example[feature] = X[feature].mean()
        elif strategies[feature] == "mode":
            example[feature] = X[feature].mode().values[0]
        else:
            raise ValueError(f"Invalid strategy: {strategies[feature]}")

    # 입력한 값으로 변경
    for key, value in kwargs.items():
        if key in example:
            example[key] = value

    # DataFrame으로 변환
    example_df = pd.DataFrame([example])

    # 승률 예측
    win_probability = model.predict_proba(example_df)[:, 1]
    return win_probability[0]


# 모델 학습 및 예측
rf.fit(X_train, y_train)
y_pred_rf = rf.predict(X_test)

# 모델 정확도 계산
accuracy_rf = accuracy_score(y_test, y_pred_rf)
print("모델 정확도: %.2f%%" % (accuracy_rf * 100.0))

# 모델 승률 예측
win_prob_rf = predict_win_probability(rf, features, strategies, blueKillScoreDiff=-5)
print(f"모델 예측된 승률: {win_prob_rf}")
