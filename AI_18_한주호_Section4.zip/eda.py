import pandas as pd

df = pd.read_csv("high_diamond_ranked_10min.csv")
drop_column = [
    "gameId",
    "redFirstBlood",
    "blueAssists",
    "redAssists",
    "blueTotalJungleMinionsKilled",
    "redTotalJungleMinionsKilled",
    "blueCSPerMin",
    "redCSPerMin",
    "redGoldDiff",
    "blueGoldPerMin",
    "redGoldPerMin",
    "redExperienceDiff",
    "redKills",
    "redDeaths",
    "redDragons",
    "redHeralds",
    "blueEliteMonsters",
    "redEliteMonsters",
]
df.drop(drop_column, axis=1, inplace=True)
df["blueKillScoreDiff"] = df["blueKills"] - df["blueDeaths"]

df.info()

df.to_csv("cleared.csv", index=False)

# profile = ProfileReport(df, title="Pandas Profiling Report")
# profile.to_widgets()  # for Jupyter notebook
# profile.to_file("output.html")  # for HTML file
