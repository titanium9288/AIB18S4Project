import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from sklearn.metrics import roc_auc_score

# 데이터 로드
data = pd.read_csv("cleared.csv")

# 특성과 라벨 분리
X = data.drop("blueWins", axis=1)
y = data["blueWins"]

# 훈련 세트와 테스트 세트 분리
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# 데이터 정규화
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# 모델 생성
model = Sequential()
model.add(Dense(32, input_dim=X_train.shape[1], activation="relu"))
model.add(Dense(16, activation="relu"))
model.add(Dense(1, activation="sigmoid"))  # 이진 분류 문제이므로 출력 레이어의 활성화 함수는 'sigmoid'를 사용

# 모델 컴파일
model.compile(loss="binary_crossentropy", optimizer="adam", metrics=["accuracy"])

# 모델 학습
model.fit(X_train, y_train, epochs=100, batch_size=32, verbose=1, validation_split=0.2)

# 모델 평가
loss, accuracy = model.evaluate(X_test, y_test, verbose=0)
print("Model accuracy: ", accuracy)

# 테스트 데이터에 대한 예측 생성
predictions = model.predict(X_test)

# 승률 예측 출력
print("승률 예측:\n", predictions)

# AUC 점수 계산
auc_score = roc_auc_score(y_test, predictions)
print("AUC Score: ", auc_score)
