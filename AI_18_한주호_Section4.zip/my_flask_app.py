from flask import Flask, render_template, request, jsonify, send_file
import pandas as pd
from sklearn.linear_model import LogisticRegression
import mysql.connector
import matplotlib.pyplot as plt
import random
import io
import base64


app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/chart", methods=["POST"])
def generate_chart():
    # 데이터 받아오기
    data = request.get_json()
    print(data)

    # MySQL 연결 정보 설정
    config = {
        "host": "host",  # 보안때문에 해당 항목들은 전부 비워둠.
        "user": "user",
        "password": "password",
        "database": "RiftWin",
    }

    # MySQL에 연결
    conn = mysql.connector.connect(**config)
    cursor = conn.cursor()

    sql = """SELECT blueWins, count(*)
    FROM match_data
    WHERE 1=1
    """
    for column in data["ids"]:
        number = 1
        operator = " = "
        if column == "blueKillScoreDiff":
            number = 5
            operator = " >= "
        if column == "blueGoldDiff":
            number = 1500
            operator = " >= "

        sql += "AND " + column + operator + str(number) + " "
    sql += "GROUP BY blueWins"

    cursor.execute(sql)
    results = cursor.fetchall()

    total = 0
    win_rate = 50
    lose_rate = 50

    for row in results:
        total += row[1]
        if row[0] == "1":
            win_rate = round(row[1] / total * 100, 1)

    print(f"total : {total}")

    if total < 2000:
        csv = pd.read_csv("cleared.csv")
        X = csv[data["ids"]]
        y = csv["blueWins"]

        model = LogisticRegression()
        model.fit(X, y)

        pred_data = []
        for i in data["ids"]:
            if i == "blueKillScoreDiff":
                pred_data.append(5)
            elif i == "blueGoldDiff":
                pred_data.append(1500)
            else:
                pred_data.append(1)

        win_rate = round(model.predict_proba([pred_data])[0][1] * 100, 1)

    lose_rate = round(100 - win_rate, 1)

    return jsonify([lose_rate, win_rate])


if __name__ == "__main__":
    app.run(debug=True)
